# Mypackage
This is my first try at building a package. This package sorts a given set list or array and return top n members 